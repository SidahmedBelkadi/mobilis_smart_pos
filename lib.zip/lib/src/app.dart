import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'core/api/dio_consumer.dart';
import 'features/sign_in/data/data_sources/sign_in_local_data_source.dart';
import 'features/sign_out/domain/use_cases/sign_out_use_case.dart';

import '../src/dependency_injection/injection_container.dart' as di;
import 'config/routing/app_routes.dart';
import 'config/theming/app_theme.dart';
import 'core/utils/helpers/route_helper.dart';
import 'core/utils/ressources/app_constants.dart';
import 'features/main/presentation/cubits/cubit/locale_cubit.dart';
import 'features/sign_out/presentation/cubit/sign_out_cubit.dart';

final navigatorKey = GlobalKey<NavigatorState>();


class SmartPos extends StatelessWidget {
  const SmartPos({super.key});

  @override
  Widget build(BuildContext context) {
    final initialRouteHelper = di.serviceLocator<InitialRouteHelper>();

    return ScreenUtilInit(
      // Resolution of pixel 6 pro (Android Studio)
      designSize: const Size(384, 832),
      // designSize: const Size(421, 892),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        // ScreenUtil.setContext(context);
        return MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => LocaleCubit()..getSavedLanguage(),
            ),
            BlocProvider(
              create: (_) => SignOutCubit(
                localDataSource: di.serviceLocator<AuthenticationLocalDataSource>(),
                useCase: di.serviceLocator<SignOutUseCase>(),
              ),
            ),
          ],
          child: BlocBuilder<LocaleCubit, ChangeLocalState>(
            builder: (context, state) {
              if (!di.serviceLocator.isRegistered<DioConsumer>()) {
                debugPrint("==== REGISTERED");
                di.serviceLocator.registerLazySingleton<DioConsumer>(
                  () => DioConsumer(client: di.serviceLocator(), context: context),
                );
              }

              return MaterialApp(
                debugShowCheckedModeBanner: true,
                title: 'MOBILIS SMART POS',
                theme: smartDealerTheme(state.locale),
                navigatorKey: navigatorKey,
                onGenerateRoute: AppRoutes.onGenerateRoute,
                initialRoute: initialRouteHelper.determineInitialRoute(),

                // ==== Localization ==== //
                locale: state.locale,
                // locale: const Locale("ar"),
                supportedLocales: supportedLocales,
                localizationsDelegates: localizationsDelegates,
                localeResolutionCallback: (deviceLocale, supportedLocales) {
                  supportedLocales.map((locale) {
                    if (deviceLocale != null &&
                        (deviceLocale.languageCode == locale.languageCode)) {
                      return deviceLocale;
                    } else {
                      return const Locale("ar");
                    }
                  });
                  return null;
                },
                // ==== Localization ==== //
              );
            },
          ),
        );
      },
    );
  }
}
