import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/utils/ressources/app_strings.dart';
import '../../../sign_in/data/data_sources/sign_in_local_data_source.dart';
import '../../domain/entities/invoice_entity.dart';
import '../../domain/use_cases/get_invoices_use_case.dart';

part 'invoices_state.dart';

class InvoicesCubit extends Cubit<InvoicesState> {
  final GetInvoicesUseCase useCase;
  final AuthenticationLocalDataSource authenticationLocalDataSource;

  InvoicesCubit({
    required this.useCase,
    required this.authenticationLocalDataSource,
  }) : super(const InvoicesInitial(selectedCategory: AppStrings.allCategory));

  int currentPage = 0;
  bool isFetching = false;
  bool hasMoreInvoices = true;
  String selectedCategory = AppStrings.allCategory;

  Future<void> getInvoices({
    bool isFirstTime = false,
    bool isFetchingMore = false,
    String? category,
  }) async {
    if (isFetching) return;
    isFetching = true;

    if (category != null) {
      selectedCategory = category;
    }

    if (isFirstTime) {
      emit(GetInvoicesLoading(selectedCategory: selectedCategory));
      currentPage = 0;
      hasMoreInvoices = true;
    } else if (isFetchingMore && state is InvoicesWithData) {
      emit(FetchingMoreInvoices(
        (state as InvoicesWithData).invoices,
        selectedCategory: selectedCategory,
      ));
    }

    // Fetch the saved login credentials asynchronously
    final savedCredentials = authenticationLocalDataSource.getSavedLoginCredentials();
    if (savedCredentials == null || savedCredentials.userId == null) {
      emit(GetInvoicesFailure(
        message: 'An error has occured',
        selectedCategory: selectedCategory,
      ));
      isFetching = false;
      return;
    }

    final failureOrInvoices = await useCase(
      page: currentPage,
      pdvId: savedCredentials.userId!,
    );

    failureOrInvoices.fold((failure) {
      emit(GetInvoicesFailure(message: failure.message, selectedCategory: selectedCategory));
    }, (invoices) {
      if (invoices.isEmpty) {
        hasMoreInvoices = false;
      } else {
        currentPage = currentPage + 9;
      }

      final filteredInvoices = _filterInvoicesByCategory(invoices, selectedCategory);
      if (isFirstTime) {
        emit(GetInvoicesSuccess(
          filteredInvoices,
          hasMoreInvoices: hasMoreInvoices,
          selectedCategory: selectedCategory,
        ));
      } else if (isFetchingMore && state is InvoicesWithData) {
        emit(GetInvoicesSuccess(
          (state as InvoicesWithData).invoices + filteredInvoices,
          hasMoreInvoices: hasMoreInvoices,
          selectedCategory: selectedCategory,
        ));
      } else {
        emit(GetInvoicesSuccess(
          filteredInvoices,
          hasMoreInvoices: hasMoreInvoices,
          selectedCategory: selectedCategory,
        ));
      }
    });

    isFetching = false;
  }

  List<InvoiceEntity> _filterInvoicesByCategory(List<InvoiceEntity> invoices, String category) {
    if (category.toLowerCase() == AppStrings.allCategory.toLowerCase()) {
      return invoices;
    }
    return invoices
        .where((invoice) => invoice.status.toLowerCase() == category.toLowerCase())
        .toList();
  }

  void selectCategory(String category) {
    getInvoices(isFirstTime: true, category: category);
  }
}
