part of 'invoices_cubit.dart';

sealed class InvoicesState extends Equatable {
  final String selectedCategory;
  const InvoicesState({required this.selectedCategory});

  @override
  List<Object> get props => [selectedCategory];
}

final class InvoicesInitial extends InvoicesState {
  const InvoicesInitial({required super.selectedCategory});
}

final class InvoicesWithData extends InvoicesState {
  final List<InvoiceEntity> invoices;
  const InvoicesWithData(this.invoices, {required super.selectedCategory});
}

final class GetInvoicesSuccess extends InvoicesWithData {
  final bool hasMoreInvoices;

  const GetInvoicesSuccess(
    super.invoices, {
    required this.hasMoreInvoices,
    required super.selectedCategory,
  });

  @override
  List<Object> get props => [invoices, selectedCategory, hasMoreInvoices];
}

final class FetchingMoreInvoices extends InvoicesWithData {
  const FetchingMoreInvoices(super.invoices, {required super.selectedCategory});

  @override
  List<Object> get props => [invoices, selectedCategory];
}

final class GetInvoicesFailure extends InvoicesState {
  final String message;

  const GetInvoicesFailure({required this.message, required super.selectedCategory});

  @override
  List<Object> get props => [message, selectedCategory];
}

final class GetInvoicesLoading extends InvoicesState {
  const GetInvoicesLoading({required super.selectedCategory});
}
