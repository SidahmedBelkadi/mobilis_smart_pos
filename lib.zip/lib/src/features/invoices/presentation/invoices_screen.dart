import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../../core/commom/widgets/idle.dart';
import '../../../core/utils/ressources/app_colors.dart';
import '../../../core/utils/helpers/app_localization_helper.dart';
import '../../../core/utils/helpers/media_query_values.dart';
import 'widgets/invoices_list_view.dart';

class InvoicesScreen extends StatelessWidget {
  const InvoicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Idle(
      child: Scaffold(
        appBar: AppBar(
          foregroundColor: Colors.black,
          backgroundColor: AppColors.secondary,
          centerTitle: true,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("mesOperations".tr(context), style: Theme.of(context).textTheme.bodyLarge),
              SizedBox(width: 10.sp),
              FaIcon(
                FontAwesomeIcons.fileInvoice,
                size: 20.sp,
              ),
            ],
          ),
        ),
        body: SafeArea(
          child: Container(
            padding: EdgeInsets.all(24.sp),
            width: context.width,
            child: const Column(
              children: [
                // ------------ Invoices Categories ListView
                // SizedBox(
                //   height: 40.sp,
                //   child: const InvoicesCategoriesListView(),
                // ),

                // SizedBox(height: 24.h),

                // ------------- Invoices List View
                Expanded(child: InvoicesListView())
              ],
            ),
          ),
        ),
      ),
    );
  }
}
