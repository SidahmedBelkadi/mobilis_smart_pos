import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/utils/ressources/app_strings.dart';
import '../../../../core/utils/helpers/app_localization_helper.dart';
import '../cubit/invoices_cubit.dart';
import 'invoice_category_item.dart';

class InvoicesCategoriesListView extends StatelessWidget {
  const InvoicesCategoriesListView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<InvoicesCubit, InvoicesState>(
      builder: (context, state) {
        String selectedCategory = state.selectedCategory;
        final cubit = context.read<InvoicesCubit>();
        return ListView(
          scrollDirection: Axis.horizontal,
          children: [
            InvoicesCategoryItem(
              text: "allCategory".tr(context),
              isSelected: selectedCategory == AppStrings.allCategory,
              onTap: () => cubit.selectCategory(AppStrings.allCategory),
            ),
            SizedBox(width: 8.w),
            InvoicesCategoryItem(
              text: "paidCategory".tr(context),
              isSelected: selectedCategory == AppStrings.paidCategory,
              onTap: () => cubit.selectCategory(AppStrings.paidCategory),
            ),
            SizedBox(width: 8.w),
            InvoicesCategoryItem(
              text: "notPaidCategory".tr(context),
              isSelected: selectedCategory == AppStrings.notPaidCategory,
              onTap: () => cubit.selectCategory(AppStrings.notPaidCategory),
            ),
          ],
        );
      },
    );
  }
}
