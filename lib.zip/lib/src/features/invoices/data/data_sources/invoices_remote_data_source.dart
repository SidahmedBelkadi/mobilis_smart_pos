import 'dart:convert';

import '../../../../core/api/dio_consumer.dart';
import '../../../../core/api/end_points.dart';
import '../models/invoice_model.dart';

abstract class InvoicesRemoteDataSource {
  Future<List<InvoiceModel>> getInvoices({required int pdvId, required int page});
}

class InvoicesRemoteDataSourceImpl implements InvoicesRemoteDataSource {
  final DioConsumer dioConsumer;

  InvoicesRemoteDataSourceImpl({required this.dioConsumer});

  @override
  Future<List<InvoiceModel>> getInvoices({required int pdvId, required int page}) async {
    final response = await dioConsumer.get("${EndPoints.invoices}/$pdvId/$page");
    final List<dynamic> decodedResponse = jsonDecode(response);

    final List<InvoiceModel> invoices =
        decodedResponse.map((e) => InvoiceModel.fromJson(e)).toList();
    // for test
    await Future.delayed(const Duration(seconds: 1));
    return invoices;
  }
}
