import 'package:flutter/material.dart';
import '../../../core/commom/widgets/idle.dart';

import '../../../core/utils/helpers/app_localization_helper.dart';
import '../../../core/utils/ressources/app_colors.dart';
import '../../sign_in/data/data_sources/sign_in_local_data_source.dart';
import 'widget/password_update.dart';
import 'widget/personal_info.dart';
import 'widget/personnel_files_update.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({
    super.key,
    required this.authenticationLocalDataSource,
  });

  final AuthenticationLocalDataSource authenticationLocalDataSource;

  @override
  Widget build(BuildContext context) {
    return Idle(
      child: DefaultTabController(
        length: 3,
        child: SafeArea(
          child: Scaffold(
            appBar: AppBar(
              bottom: TabBar(
                indicatorColor: AppColors.primary,
                dividerColor: AppColors.secondaryLight,
                tabs: [
                  Tab(
                    text: "profile_info".tr(context),
                  ),
                  Tab(
                    text: "documents".tr(context),
                  ),
                  Tab(
                    text: "password".tr(context),
                  ),
                ],
              ),
            ),
            body: TabBarView(
              children: [
                const ProfilePersonalInformations(),
                const ProfilePersonnelFilesUpdate(),
                ProfilePasswordUpdate(authenticationLocalDataSource: authenticationLocalDataSource),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
