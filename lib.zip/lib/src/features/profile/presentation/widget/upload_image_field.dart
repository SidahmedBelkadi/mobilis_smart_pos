import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/utils/helpers/media_query_values.dart';
import '../../../../core/utils/ressources/app_colors.dart';

class UploadImageField extends StatelessWidget {
  const UploadImageField({
    super.key,
    required this.label,
    required this.onTap,
  });

  final String label;
  final void Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          label,
          style: Theme.of(context)
              .textTheme
              .labelMedium!
              .copyWith(fontWeight: FontWeight.bold, color: AppColors.primary),
        ),
        SizedBox(height: 10.h),
        GestureDetector(
          onTap: onTap,
          child: SizedBox(
            width: context.width,
            height: 64.sp,
            child: DottedBorder(
              color: AppColors.primary,
              dashPattern: const [5, 5],
              strokeWidth: 2,
              radius: Radius.circular(12.sp),
              borderType: BorderType.RRect,
              child: const Center(
                child: Icon(Icons.add, color: AppColors.primary),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
