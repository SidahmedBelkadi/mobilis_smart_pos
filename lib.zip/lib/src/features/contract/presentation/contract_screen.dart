import 'dart:io';

import 'package:diacritic/diacritic.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:mobilis_smart_pos/src/features/contract/domain/entities/daira_entity.dart';
import 'package:mobilis_smart_pos/src/features/contract/domain/entities/wilaya_entity.dart';
import 'package:mobilis_smart_pos/src/services/screenshot_service.dart';
import '../../sign_out/presentation/cubit/sign_out_cubit.dart';

import '../../../config/routing/app_routes.dart';
import '../../../core/commom/widgets/app_text_form_field.dart';
import '../../../core/commom/widgets/camera_screen.dart';
import '../../../core/commom/widgets/commune_drop_down.dart';
import '../../../core/commom/widgets/daira_drop_down.dart';
import '../../../core/commom/widgets/wilaya_drop_down.dart';
import '../../../core/utils/enums/input_type.dart';
import '../../../core/utils/helpers/app_localization_helper.dart';
import '../../../core/utils/helpers/civils_informations_converter_helper.dart';
import '../../../core/utils/helpers/json_loader_helper.dart';
import '../../../core/utils/helpers/media_query_values.dart';
import '../../../core/utils/helpers/toast_helper.dart';
import '../../../core/utils/ressources/app_colors.dart';
import '../../../dependency_injection/injection_container.dart' as di;
import '../../sign_in/data/data_sources/sign_in_local_data_source.dart';
import '../domain/entities/commune_entity.dart';
import '../domain/entities/contract_request_params_entitiy.dart';

class ContractScreen extends StatefulWidget {
  const ContractScreen({
    super.key,
    required this.metaData,
    required this.isMinor,
  });

  final Map metaData;
  final bool isMinor;

  @override
  State<ContractScreen> createState() => _ContractScreenState();
}

late TextEditingController ninController;
late TextEditingController docNumberController;
late TextEditingController issuingCountryController;
late TextEditingController issuingPlaceControllerController;
late TextEditingController issuingDateController;
late TextEditingController docTypeController;
late TextEditingController bloodTypeController;

late TextEditingController firstNameEditingController;
late TextEditingController lastNameEditingController;
late TextEditingController genderEditingController;
late TextEditingController birthDateEditingController;
late TextEditingController birthPlaceEditingController;
late TextEditingController nationalityEditingController;
late TextEditingController addressEditingController;
late TextEditingController emailEditingController;
GlobalKey<FormState> _formKey = GlobalKey();

class _ContractScreenState extends State<ContractScreen> {
  List<Wilaya> _wilayas = [];
  List<Commune> _communes = [];
  List<Commune> _filteredCommunes = [];
  String? _selectedWilaya;
  String? _selectedCommune;

  Future<void> _loadData() async {
    final wilayas = await JsonLoaderHelper.loadWilayas();
    final communes = await JsonLoaderHelper.loadCommunes();
    setState(() {
      _wilayas = wilayas;
      _communes = communes;
    });
  }

  void _filterCommunes(String? wilayaCode) {
    setState(() {
      _selectedWilaya = wilayaCode;
      _selectedCommune = null;
      _filteredCommunes = _communes.where((commune) => commune.stateCode == wilayaCode).toList();
    });
  }


  File? rectoImage;
  File? versoImage;
  bool isCaptureDone = false;

  Future<void> _pickImage({required bool isRecto}) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => CameraScreen(
        onPictureTaken: (File image) {
          setState(() {
            if (isRecto) {
              rectoImage = image;
              debugPrint("============= RECTO $rectoImage");
            } else {
              versoImage = image;
              debugPrint("============= VERSO $versoImage");
            }
          });

          if (widget.metaData['Doc_type'] == 'Passport' && rectoImage != null) {
            setState(() {
              isCaptureDone = true;
            });
          } else if (!isRecto && versoImage != null) {
            setState(() {
              isCaptureDone = true;
            });
          }
        },
      ),
    ));
    if (isRecto && rectoImage != null && widget.metaData['Doc_type'] != 'Passport') {
      _showImageDialog(
        // ignore: use_build_context_synchronously
        title: "verso_instruction".tr(context),
        isRecto: false,
      );
    }
  }

  Future<void> _showImageDialog({required String title, required bool isRecto}) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            title,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          actions: <Widget>[
            TextButton(
              child: Text('ok'.tr(context)),
              onPressed: () async {
                Navigator.of(context).pop();
                await _pickImage(isRecto: isRecto);
              },
            ),
          ],
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();

    ScreenshotService.disableScreenshots();

    _loadData();

    ninController = TextEditingController();
    docNumberController = TextEditingController();
    issuingCountryController = TextEditingController();
    issuingPlaceControllerController = TextEditingController();
    issuingDateController = TextEditingController();
    docTypeController = TextEditingController();
    bloodTypeController = TextEditingController();

    firstNameEditingController = TextEditingController();
    lastNameEditingController = TextEditingController();
    genderEditingController = TextEditingController();
    birthDateEditingController = TextEditingController();
    birthPlaceEditingController = TextEditingController();
    nationalityEditingController = TextEditingController();
    addressEditingController = TextEditingController();
    emailEditingController = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();

    ninController.dispose();
    docNumberController.dispose();
    issuingCountryController.dispose();
    issuingPlaceControllerController.dispose();
    issuingDateController.dispose();
    docTypeController.dispose();
    bloodTypeController.dispose();

    firstNameEditingController.dispose();
    lastNameEditingController.dispose();
    genderEditingController.dispose();
    birthDateEditingController.dispose();
    birthPlaceEditingController.dispose();
    nationalityEditingController.dispose();
    addressEditingController.dispose();
  }

  late ContractRequestParamsEntitiy contract;

  _onFABPressed() async {
    bool isValidated = _formKey.currentState!.validate();

    if (!isValidated) {
      AppToasts.showErrorToast(
        message: "all_fields".tr(context),
        onAutoCompleteCompleted: (p0) {},
        context: context,
      );
      return;
    }

    if (_selectedWilaya == null) {
      AppToasts.showErrorToast(
        message: "required_wilaya".tr(context),
        onAutoCompleteCompleted: (p0) {},
        context: context,
      );
      return;
    }

    if (_selectedCommune == null) {
      AppToasts.showErrorToast(
        message: "required_commune".tr(context),
        onAutoCompleteCompleted: (p0) {},
        context: context,
      );
      return;
    }

    if (RegExp(r'[\u0600-\u06FF]').hasMatch(addressEditingController.text)) {
      AppToasts.showErrorToast(message: "address_french_instruction".tr(context), context: context);
      return;
    }

    // Trim text fields and assign to variables
    String nin = ninController.text.trim();
    String docNumber = docNumberController.text.trim();
    String issuingCountry = issuingCountryController.text.trim();
    String issuingPlace = issuingPlaceControllerController.text.trim();
    String docType = docTypeController.text.trim();
    String bloodType = bloodTypeController.text.trim();

    String firstName = firstNameEditingController.text.trim();
    firstName = firstName.replaceAll(RegExp(r'-\s*'), ' ');
    String lastName = lastNameEditingController.text.trim();
    lastName = lastName.replaceAll(RegExp(r'-\s*'), ' ');
    String birthPlace = birthPlaceEditingController.text.trim();
    String nationality = nationalityEditingController.text.trim();
    String normalizedAddress = removeDiacritics(addressEditingController.text.trim());
    String cleanedAddress = normalizedAddress.replaceAll(RegExp(r'[^a-zA-Z0-9 ]'), '');
    String address = cleanedAddress;

    late int pdvId;
    late int employeeId;
    final getSavedLoginCredentials =
        di.serviceLocator<AuthenticationLocalDataSource>().getSavedLoginCredentials();
    if (getSavedLoginCredentials != null) {
      pdvId = getSavedLoginCredentials.userId!;
      employeeId = getSavedLoginCredentials.employeeId!;
    } else {
      context.read<SignOutCubit>().signOut(context);
      return;
    }

    contract = ContractRequestParamsEntitiy(
      firstName: firstName,
      lastName: lastName,
      gender: CivilsInformationsConverterHelper.getToSubmitGenderValue(
          gender: widget.metaData['gender']),
      birthDate: CivilsInformationsConverterHelper.convertToIso8601WithTiret(
          widget.metaData['date_of_birth']),
      birthPlace: birthPlace,
      nationality: nationality,
      wilayaId: int.parse(_selectedWilaya!),
      commune: _selectedCommune!,
      street: address,
      folderUrl: null,
      nin: nin,
      documentType:
          CivilsInformationsConverterHelper.getToSubmitDocumentTypeValue(docType: docType),
      documentNumber: docNumber,
      issuingCountry: issuingCountry,
      issuingPlace: issuingPlace,
      issueDate: CivilsInformationsConverterHelper.convertToIso8601WithTiret(
          widget.metaData['date_of_delivery']),
      bloodGroup: bloodType,
      pdvId: pdvId,
      employeeId: employeeId,
      email: emailEditingController.text.trim(),
    );
    debugPrint("========= CONTRACT DATA : \n ${contract.toJson()}");
    ScreenshotService.enableScreenshots();
    widget.isMinor
        ? Navigator.of(context).pushNamed(Routes.parentPreparation, arguments: {
            'contract': contract,
            'recto': rectoImage,
            'verso': versoImage,
            'isPassport': widget.metaData['Doc_type'] == 'Passport' ? true : false
          })
        : Navigator.of(context).pushNamed(Routes.barCode, arguments: {
            'contract': contract,
            'recto': rectoImage,
            'verso': versoImage,
            'isPassport': widget.metaData['Doc_type'] == 'Passport' ? true : false
          });
  }

  _onCaptureFAbPressed() async {
    if (widget.metaData['Doc_type'] == 'Passport') {
      await _showImageDialog(
        title: "passport_instruction".tr(context),
        isRecto: true,
      );
    } else {
      await _showImageDialog(
        title: "recto_instruction".tr(context),
        isRecto: true,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        floatingActionButton: isCaptureDone
            ? FloatingActionButton.extended(
                heroTag: 'continue',
                label: Text("nextButton".tr(context)),
                onPressed: _onFABPressed,
                icon: context.isArabicLocale ? null : const Icon(Icons.arrow_forward),
              )
            : FloatingActionButton(
                heroTag: 'capture',
                onPressed: _onCaptureFAbPressed,
                child: const Icon(CupertinoIcons.camera_on_rectangle),
              ),
        body: SingleChildScrollView(
          child: Container(
            width: context.width,
            padding: EdgeInsets.fromLTRB(24.sp, 32.sp, 24.sp, 96.sp),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  // =============== Document Civil
                  CivilsDocument(widget: widget),

                  // =============== Info Client

                  Row(
                    children: [
                      const Icon(Icons.arrow_right_sharp),
                      Text(
                        "infos_client".tr(context),
                        style: Theme.of(context)
                            .textTheme
                            .bodyMedium!
                            .copyWith(decoration: TextDecoration.underline),
                      ),
                    ],
                  ),
                  SizedBox(height: 24.h),
                  Column(
                    children: [
                      AppTextFormField(
                        enabled: false,
                        disabledValue: widget.metaData['first_name'],
                        textEditingController: firstNameEditingController,
                        label: "firstNameLabel".tr(context),
                        // validationType: InputType.FIRST_NAME,
                      ),
                      SizedBox(height: 16.sp),
                      AppTextFormField(
                        enabled: false,
                        disabledValue: widget.metaData['last_name'],
                        textEditingController: lastNameEditingController,
                        label: "lastNameLabel".tr(context),
                      ),
                      SizedBox(height: 16.sp),

                      AppTextFormField(
                        enabled: false,
                        disabledValue: CivilsInformationsConverterHelper.getFormatedGender(
                            gender: widget.metaData['gender'], context: context),
                        textEditingController: genderEditingController,
                        label: "genderLabel".tr(context),
                      ),
                      SizedBox(height: 16.sp),
                      AppTextFormField(
                        enabled: false,
                        disabledValue: CivilsInformationsConverterHelper.formatToDisplayDate(
                            date: widget.metaData['date_of_birth'], context: context),
                        textEditingController: birthDateEditingController,
                        label: "birthDateLabel".tr(context),
                      ),
                      SizedBox(height: 16.sp),
                      AppTextFormField(
                        enabled: false,
                        disabledValue: widget.metaData['place_of_birth'],
                        textEditingController: birthPlaceEditingController,
                        label: "birthPlaceLabel".tr(context),
                      ),
                      SizedBox(height: 16.sp),
                      AppTextFormField(
                        enabled: false,
                        disabledValue: widget.metaData['Nationality'],
                        textEditingController: nationalityEditingController,
                        label: "nationality".tr(context),
                      ),
                      SizedBox(height: 16.sp),
                      // === Wilaya & daira & commune drop downs
                      WilayaDropDown(
                        items: _wilayas,
                        onChanged: (value) {
                          _filterCommunes(value);
                        },
                      ),
                      SizedBox(height: 16.sp),
                      CommuneDropDown(
                        items: _filteredCommunes,
                        selectedValue: _selectedCommune,
                        onChanged: (value) {
                          setState(() {
                            _selectedCommune = value;
                          });
                        },
                      ),
                      SizedBox(height: 16.sp),
                      AppTextFormField(
                        isLatinOnly: true,
                        label: "streetLabel".tr(context),
                        validationType: InputType.ADDRESS,
                        textEditingController: addressEditingController,
                      ),
                      SizedBox(height: 16.sp),
                      AppTextFormField(
                        isRequired: false,
                        label: "email".tr(context),
                        validationType: InputType.EMAIL,
                        textEditingController: emailEditingController,
                      ),
                      SizedBox(height: 16.sp),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      foregroundColor: Colors.black,
      backgroundColor: AppColors.secondary,
      centerTitle: true,
      title: Text(
        "contractTitle".tr(context),
        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
              fontWeight: FontWeight.bold,
            ),
      ),
      actions: [
        PopupMenuButton<String>(
          onSelected: (value) {},
          itemBuilder: (context) {
            return [
              PopupMenuItem<String>(
                onTap: () {
                  Navigator.of(context).pushNamedAndRemoveUntil(Routes.main, (route) => false);
                },
                value: 'cancel',
                child: Text("discard_activation".tr(context)),
              ),
            ];
          },
        ),
      ],
    );
  }
}

class CivilsDocument extends StatelessWidget {
  const CivilsDocument({
    super.key,
    required this.widget,
  });

  final ContractScreen widget;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            const Icon(Icons.arrow_right_sharp),
            Text(
              "infos_civil".tr(context),
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium!
                  .copyWith(decoration: TextDecoration.underline),
            ),
          ],
        ),
        SizedBox(height: 16.sp),
        AppTextFormField(
          enabled: false,
          disabledValue: CivilsInformationsConverterHelper.getDocumentTypeName(
            docType: widget.metaData['document_type'],
            context: context,
          ),
          textEditingController: docTypeController,
          label: "documentTypeLabel".tr(context),
        ),
        SizedBox(height: 16.sp),
        AppTextFormField(
          enabled: false,
          disabledValue: widget.metaData['personal_number'],
          textEditingController: ninController,
          label: "ninLabel".tr(context),
          keyboardType: TextInputType.number,
        ),
        SizedBox(height: 16.sp),
        AppTextFormField(
          enabled: false,
          disabledValue: widget.metaData['document_number'],
          textEditingController: docNumberController,
          label: "documentNumberLabel",
          keyboardType: TextInputType.number,
        ),
        SizedBox(height: 16.sp),
        AppTextFormField(
          enabled: false,
          disabledValue: widget.metaData['issuing_state'],
          textEditingController: issuingCountryController,
          label: "issuingCountryLabel".tr(context),
        ),
        SizedBox(height: 16.sp),
        AppTextFormField(
          enabled: false,
          disabledValue: widget.metaData['issuing_authority'],
          label: "issuingPlaceLabel".tr(context),
          textEditingController: issuingPlaceControllerController,
        ),
        SizedBox(height: 16.sp),
        AppTextFormField(
          enabled: false,
          disabledValue: CivilsInformationsConverterHelper.formatToDisplayDate(
              date: widget.metaData['date_of_delivery'], context: context),
          textEditingController: issuingDateController,
          label: "issuingDateLabel".tr(context),
        ),
        SizedBox(height: 16.sp),
        SizedBox(height: 32.sp),
      ],
    );
  }
}
