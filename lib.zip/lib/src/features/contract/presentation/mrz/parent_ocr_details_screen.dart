import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:mobilis_smart_pos/src/config/routing/app_routes.dart';
import 'package:mobilis_smart_pos/src/core/commom/widgets/app_text_form_field.dart';
import 'package:mobilis_smart_pos/src/core/utils/helpers/app_localization_helper.dart';
import 'package:mobilis_smart_pos/src/core/utils/helpers/media_query_values.dart';
import 'package:mobilis_smart_pos/src/core/utils/helpers/toast_helper.dart';
import 'package:mobilis_smart_pos/src/core/utils/ressources/app_colors.dart';
import 'package:mobilis_smart_pos/src/features/contract/domain/entities/contract_request_params_entitiy.dart';
import 'package:mobilis_smart_pos/src/services/screenshot_service.dart';

class ParentOcrDetails extends StatefulWidget {
  const ParentOcrDetails({
    super.key,
    required this.documentNumber,
    required this.dateOfBirth,
    required this.dateOfExpiry,
    required this.docType,
    required this.minorContract,
    this.minorRecto,
    this.minorVerso,
    required this.minorIsPassport,
    required this.parentIsPassport,
  });

  final String documentNumber;
  final String dateOfBirth;
  final String dateOfExpiry;
  final String docType;
  final ContractRequestParamsEntitiy minorContract;
  final File? minorRecto;
  final File? minorVerso;
  final bool minorIsPassport;
  final bool parentIsPassport;

  @override
  ParentOcrDetailsState createState() => ParentOcrDetailsState();
}

class ParentOcrDetailsState extends State<ParentOcrDetails> {
  late TextEditingController documentNumberController;
  late TextEditingController birthDateController;
  late TextEditingController expirationDateController;

  bool isExpired = false;
  bool isMinor = false;

  @override
  void initState() {
    super.initState();

    ScreenshotService.disableScreenshots();

    _compareDates();

    documentNumberController = TextEditingController();
    birthDateController = TextEditingController();
    expirationDateController = TextEditingController();
  }

  @override
  void dispose() {
    documentNumberController.dispose();
    birthDateController.dispose();
    expirationDateController.dispose();
    super.dispose();
  }

  void _compareDates() {
    final expirationDate = widget.dateOfExpiry;
    final birthDate = widget.dateOfBirth;

    final expirationDateParsed = _parseDate(expirationDate, true);
    final currentDate = DateTime.now();

    if (expirationDateParsed.isBefore(currentDate)) {
      setState(() {
        isExpired = true;
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        AppToasts.showErrorToast(
          message: "card_expired".tr(context),
          context: context,
        );
      });
    }

    final birthDateParsed = _parseDate(birthDate, false);
    final age = currentDate.year - birthDateParsed.year;

    if (age < 19 ||
        (age == 19 && currentDate.isBefore(birthDateParsed.add(const Duration(days: 365 * 19))))) {
      setState(() {
        isMinor = true;
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        AppToasts.showErrorToast(
          message: "This card should be a parent card".tr(context),
          context: context,
        );
      });
    }
  }

// Helper function to parse the yymmdd format
  DateTime _parseDate(String date, bool isExpiryDate) {
    // Assuming date format is yymmdd
    final year = int.parse(date.substring(0, 2));
    final month = int.parse(date.substring(2, 4));
    final day = int.parse(date.substring(4, 6));

    // Determine the century (assuming 1900-2099 range)
    final currentYear = DateTime.now().year;
    final century = (year + 2000 <= currentYear) ? 2000 : 1900;

    return DateTime(isExpiryDate ? 2000 + year : century + year, month, day);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        floatingActionButton: isExpired || isMinor
            ? null
            : Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: context.isArabicLocale
                        ? EdgeInsets.only(right: 32.sp)
                        : EdgeInsets.only(left: 32.sp),
                    child: FloatingActionButton(
                      heroTag: 're-scan',
                      backgroundColor: AppColors.secondary,
                      foregroundColor: Colors.black,
                      onPressed: () {
                        Navigator.of(context).pushNamedAndRemoveUntil(
                          Routes.main,
                          arguments: {'index': 1},
                          (route) => false,
                        );
                      },
                      child: const Icon(Icons.repeat),
                    ),
                  ),
                  FloatingActionButton.extended(
                    heroTag: 'continue-to-nfc',
                    onPressed: () async {
                      ScreenshotService.enableScreenshots();
                      Navigator.of(context).pushNamed(Routes.nfcReader, arguments: {
                        'documentNumber': widget.documentNumber,
                        'dateOfBirth': widget.dateOfBirth,
                        'dateOfExpiry': widget.dateOfExpiry,
                        'docType': widget.docType,
                        'isMinor': false,
                        'minorContract': widget.minorContract,
                        'minorRecto': widget.minorRecto,
                        'minorVerso': widget.minorVerso,
                        'minorIsPassport': widget.minorIsPassport,
                        'parentIsPassport': widget.parentIsPassport,
                      });
                    },
                    label: Row(
                      children: [
                        Text(
                          "continuer".tr(context),
                          style: const TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 5.sp),
                        const Icon(CupertinoIcons.right_chevron)
                      ],
                    ),
                    backgroundColor: AppColors.secondary,
                  ),
                ],
              ),
        body: SingleChildScrollView(
          child: Container(
            width: context.width,
            height: context.height - 200.h,
            padding: EdgeInsets.all(32.sp),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                const ScanInstruction(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      children: [
                        AppTextFormField(
                          label: "documentNumberLabel".tr(context),
                          textEditingController: documentNumberController,
                          enabled: false,
                          disabledValue: widget.documentNumber,
                        ),
                        SizedBox(height: 16.h),
                        AppTextFormField(
                          label: "birthDateLabel".tr(context),
                          textEditingController: birthDateController,
                          enabled: false,
                          disabledValue: widget.dateOfBirth,
                        ),
                        SizedBox(height: 16.h),
                        AppTextFormField(
                          label: "expirationDateLabel".tr(context),
                          textEditingController: expirationDateController,
                          enabled: false,
                          disabledValue: widget.dateOfExpiry,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      foregroundColor: Colors.black,
      backgroundColor: AppColors.secondary,
      centerTitle: true,
      title: Text(
        "Step Parent 02 : Resultat MRZ",
        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
              fontWeight: FontWeight.bold,
            ),
      ),
    );
  }
}

class ScanInstruction extends StatelessWidget {
  const ScanInstruction({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: context.width,
          padding: EdgeInsets.symmetric(horizontal: 12.sp, vertical: 16.sp),
          decoration: BoxDecoration(
            color: Colors.green.withOpacity(.1),
            borderRadius: BorderRadius.all(
              Radius.circular(12.sp),
            ),
          ),
          child: Text(
            "mrz_result_instruction".tr(context),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                  color: Colors.green,
                  fontWeight: FontWeight.bold,
                ),
          ),
        ),
      ],
    );
  }
}
