import 'dart:ui' as ui;
import 'dart:ui';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:opencv_dart/opencv_dart.dart';

import '../../../../core/utils/enums/documents_type.dart';
import '../../../../core/utils/helpers/image_processor_helper.dart';

class ObjectDetectionScreen2 extends StatefulWidget {
  const ObjectDetectionScreen2({super.key});

  @override
  ObjectDetectionScreen2State createState() => ObjectDetectionScreen2State();
}

class ObjectDetectionScreen2State extends State<ObjectDetectionScreen2> {
  CameraController? _cameraController;
  Future<void>? _initializeControllerFuture;
  bool _isProcessing = false;
  bool _isDocumentDetected = false;

  List<Offset>? _documentPolygon;
  late TextRecognizer _textRecognizer;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _textRecognizer = TextRecognizer();
  }

  List<Offset> _scalePolygonToPreview(
      List<Offset> polygon, ui.Size imageSize, ui.Size previewSize) {
    double scaleX = previewSize.width / imageSize.width;
    double scaleY = previewSize.height / imageSize.height;

    return polygon.map((point) {
      return Offset(point.dx * scaleX, point.dy * scaleY);
    }).toList();
  }

  Future<void> _initializeCamera() async {
    final cameras = await availableCameras();
    final firstCamera = cameras.first;

    _cameraController = CameraController(
      firstCamera,
      ResolutionPreset.ultraHigh,
      enableAudio: false,
    );

    _initializeControllerFuture = _cameraController!.initialize();
    await _initializeControllerFuture;
    if (mounted) {
      setState(() {});
    }

    _cameraController!.startImageStream(_processCameraImage);
  }

  Future<void> _processCameraImage(CameraImage image) async {
    if (_isProcessing) return;
    _isProcessing = true;

    try {
      final inputImage = ImageHelper.convertCameraImageToInputImage(image, _cameraController!);
      final recognizedText = await _textRecognizer.processImage(inputImage);

      // Checking if the document is recognized by the text recognizer if yes .. start object detection
      if (ImageHelper.isDocumentRecognized(recognizedText.text, DocumentsType.frontIdCard)) {
        // Here i am Converting the CameraImage to OpenCV Mat format
        final inputMat = await _convertCameraImageToMat(image);

        // Here i am Detecting the document and get the polygon points
        final detectedPolygon = await _detectDocument(inputMat);

        if (detectedPolygon != null) {
          // Here i am Scaling the polygon to fit the CameraPreview
          final previewSize = MediaQuery.of(context).size;
          final imageSize = ui.Size(image.width.toDouble(), image.height.toDouble());
          final scaledPolygon = _scalePolygonToPreview(detectedPolygon, imageSize, previewSize);

          setState(() {
            _isDocumentDetected = true;
            _documentPolygon = scaledPolygon;
          });
        } else {
          setState(() {
            _isDocumentDetected = false;
            _documentPolygon = null;
          });
        }
      } else {
        setState(() {
          _isDocumentDetected = false;
          _documentPolygon = null;
        });
      }
    } catch (e) {
      debugPrint('Error processing image: $e');
    } finally {
      _isProcessing = false;
    }
  }

  Future<Mat> _convertCameraImageToMat(CameraImage image) async {
    final int width = image.width;
    final int height = image.height;

    final Uint8List yBuffer = image.planes[0].bytes;

    final List<int> pixelValues = yBuffer.map((e) => e.toInt()).toList();

    return Mat.fromList(height, width, MatType.CV_8UC1, pixelValues);
  }

  Future<List<Offset>?> _detectDocument(Mat mat) async {
    try {
      final blurred = await gaussianBlurAsync(mat, (5, 5), 0);

      final edged = await cannyAsync(blurred, 50, 150);

      final (contours, hierarchy) = await findContoursAsync(
        edged,
        RETR_EXTERNAL,
        CHAIN_APPROX_SIMPLE,
      );

      for (int i = 0; i < contours.length; i++) {
        final contour = contours[i];
        final perimeter = await arcLengthAsync(contour, true);

        final precision = (0.02 * perimeter).toInt();
        final approx = await approxPolyDPAsync(contour, precision.toDouble(), true);

        if (approx.length == 4 && await contourAreaAsync(contour) > 500) {
          final polygon = approx.map((point) {
            return Offset(point.x.toDouble(), point.y.toDouble());
          }).toList();

          // Note: Here i am  exapnding the bounding box slightly (you can remove the the margin then make it precise)
          return _expandPolygon(polygon, 25);
        }
      }
      return null; // No document detected
    } catch (e) {
      debugPrint('Error in document detection: $e');
      return null;
    }
  }

  List<Offset> _expandPolygon(List<Offset> polygon, double margin) {
    final centroid = Offset(
      polygon.map((p) => p.dx).reduce((a, b) => a + b) / polygon.length,
      polygon.map((p) => p.dy).reduce((a, b) => a + b) / polygon.length,
    );

    return polygon.map((point) {
      final dx = point.dx - centroid.dx;
      final dy = point.dy - centroid.dy;
      return Offset(
        point.dx + (dx * margin / 60),
        point.dy + (dy * margin / 90),
      );
    }).toList();
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Stack(
              fit: StackFit.expand,
              children: [
                CameraPreview(_cameraController!),
                if (_isDocumentDetected && _documentPolygon != null)
                  CustomPaint(
                    painter: PolygonPainter(polygon: _documentPolygon!),
                  ),
              ],
            );
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}

class PolygonPainter extends CustomPainter {
  final List<Offset> polygon;
  final double borderRadius; // Radius for the rounded corners

  PolygonPainter({required this.polygon, this.borderRadius = 10.0});

  @override
  void paint(Canvas canvas, ui.Size size) {
    final paint = Paint()
      ..color = Colors.green
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0
      ..strokeCap = StrokeCap.round;

    final path = _createRoundedPolygon(polygon, borderRadius);

    final dashPattern = [10.0, 5.0];
    _drawDashedPath(canvas, path, paint, dashPattern);
  }

  Path _createRoundedPolygon(List<Offset> points, double radius) {
    final path = Path();
    if (points.isEmpty) return path;

    final firstPoint = points[0];
    path.moveTo(firstPoint.dx, firstPoint.dy);

    for (int i = 0; i < points.length; i++) {
      final currentPoint = points[i];
      final nextPoint = points[(i + 1) % points.length];
      final prevPoint = points[(i - 1 + points.length) % points.length];

      final offsetFromPrev = (currentPoint - prevPoint).direction;
      final offsetToNext = (nextPoint - currentPoint).direction;

      final offsetRadius = radius / 2;
      final start = currentPoint - Offset.fromDirection(offsetFromPrev, offsetRadius);
      final end = currentPoint + Offset.fromDirection(offsetToNext, offsetRadius);

      path.lineTo(start.dx, start.dy);
      path.arcToPoint(
        end,
        radius: Radius.circular(radius),
        clockwise: true,
      );
    }
    path.close();
    return path;
  }

  void _drawDashedPath(Canvas canvas, Path path, Paint paint, List<double> dashPattern) {
    final PathMetrics pathMetrics = path.computeMetrics();
    for (final PathMetric pathMetric in pathMetrics) {
      final double totalLength = pathMetric.length;
      double distance = 0.0;
      int patternIndex = 0;

      while (distance < totalLength) {
        final double patternLength = dashPattern[patternIndex];
        final bool isDrawing = patternIndex.isEven;
        final double segmentLength =
            (distance + patternLength) <= totalLength ? patternLength : totalLength - distance;

        if (isDrawing) {
          final Path extractedPath = pathMetric.extractPath(distance, distance + segmentLength);
          canvas.drawPath(extractedPath, paint);
        }

        distance += segmentLength;
        patternIndex = (patternIndex + 1) % dashPattern.length;
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
