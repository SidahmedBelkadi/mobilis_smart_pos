import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'package:mobilis_smart_pos/src/core/commom/widgets/camera_screen.dart';
import 'package:mobilis_smart_pos/src/core/utils/helpers/app_localization_helper.dart';
import 'package:mobilis_smart_pos/src/core/utils/helpers/civils_informations_converter_helper.dart';
import 'package:mobilis_smart_pos/src/core/utils/ressources/app_colors.dart';
import 'package:mobilis_smart_pos/src/core/utils/ressources/app_images.dart';
import 'package:mobilis_smart_pos/src/features/contract/domain/entities/contract_request_params_entitiy.dart';
import 'package:mobilis_smart_pos/src/services/screenshot_service.dart';

import '../../../config/routing/app_routes.dart';

class ParentDocumentScreen extends StatefulWidget {
  const ParentDocumentScreen({
    super.key,
    required this.minorContract,
    this.minorRecto,
    this.minorVerso,
    required this.minorIsPassport,
    required this.parentIsPassport,
    required this.parentExtractedNFCData,
  });

  final ContractRequestParamsEntitiy minorContract;
  final File? minorRecto;
  final File? minorVerso;
  final bool minorIsPassport;
  final bool parentIsPassport;
  final Map<String, dynamic> parentExtractedNFCData;

  @override
  State<ParentDocumentScreen> createState() => _ParentDocumentScreenState();
}

class _ParentDocumentScreenState extends State<ParentDocumentScreen> {
  File? recto;
  File? verso;
  bool isCaptureDone = false;

  Future<void> _pickImage({required bool isRecto}) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => CameraScreen(
        onPictureTaken: (File image) {
          setState(() {
            if (isRecto) {
              recto = image;
            } else {
              verso = image;
            }
          });

          if (widget.parentIsPassport && recto != null) {
            setState(() {
              isCaptureDone = true;
            });
          } else if (!isRecto && verso != null) {
            setState(() {
              isCaptureDone = true;
            });
          }
        },
      ),
    ));
    if (isRecto && recto != null && !widget.parentIsPassport) {
      _showImageDialog(
        title: "verso_instruction".tr(context),
        isRecto: false,
      );
    }
  }

  Future<void> _showImageDialog({required String title, required bool isRecto}) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              if(!isRecto) LottieBuilder.asset(AppImages.flip) ,
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('ok'.tr(context)),
              onPressed: () async {
                Navigator.of(context).pop();
                await _pickImage(isRecto: isRecto);
              },
            ),
          ],
        );
      },
    );
  }

  _onCaptureFAbPressed() async {
    if (widget.parentIsPassport) {
      await _showImageDialog(
        title: "passport_instruction".tr(context),
        isRecto: true,
      );
    } else {
      await _showImageDialog(
        title: "recto_instruction".tr(context),
        isRecto: true,
      );
    }
  }

  _debugInformations() {
    debugPrint("========== Minor Contract  :  ${widget.minorContract}");
    debugPrint("========== Minor Recto : ${widget.minorRecto}");
    debugPrint("========== Minor Verso : ${widget.minorVerso}");
    debugPrint("========== Minor Is Passport : ${widget.minorIsPassport}");
    debugPrint("========== Prent Is Passport : ${widget.parentIsPassport}");
    debugPrint("========== Parent Data : ${widget.parentExtractedNFCData}");
    debugPrint("========== Parent Recto : $recto");
    debugPrint("========== Parent Verso : $verso");
    debugPrint('================================ ==========================');
  }

  _navigateToBarCodeScreen() {
    var parentData = widget.parentExtractedNFCData;
    ContractRequestParamsEntitiy contract = widget.minorContract.copyWith(
      parentFirstName: parentData['first_name'],
      parentLastName: parentData['last_name'],
      parentGender: CivilsInformationsConverterHelper.getToSubmitGenderValue(
        gender: parentData['gender'],
      ),
      parentBirthDate: CivilsInformationsConverterHelper.convertToIso8601WithTiret(
        parentData['date_of_birth'],
      ),
      parentBirthPlace: parentData['place_of_birth'],
      parentNationality: parentData['Nationality'],
      parentWilayaId: widget.minorContract.wilayaId,
      parentCommune: widget.minorContract.commune,
      parentStreet: widget.minorContract.street,
      parentNin: parentData['personal_number'],
      parentDocumentType: CivilsInformationsConverterHelper.getToSubmitDocumentTypeValue(
        docType: parentData['document_type'],
      ),
      parentDocumentNumber: parentData['document_number'],
      parentIssuingCountry: parentData['issuing_state'],
      parentIssuingPlace: parentData['issuing_authority'],
      parentIssueDate: CivilsInformationsConverterHelper.convertToIso8601WithTiret(
        parentData['date_of_delivery'],
      ),
    );

    _debugInformations();
    debugPrint(
        "========== Parent Data : ${const JsonEncoder.withIndent("     ").convert(contract.toJson())}}");
    ScreenshotService.enableScreenshots();
    Navigator.of(context).pushNamed(Routes.barCode, arguments: {
      'contract': contract,
      'recto': widget.minorRecto,
      'verso': widget.minorVerso,
      'isPassport': widget.minorIsPassport,
      'parentRecto' : recto,
      'parentVerso' : verso,
      'parentIsPassport' : widget.parentIsPassport
    });
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: isCaptureDone ? _navigateToBarCodeScreen : _onCaptureFAbPressed,
          child: isCaptureDone ? const Icon(Icons.arrow_right) : const Icon(Icons.camera_enhance),
        ),
        appBar: AppBar(title: Text("Parent Document", style: Theme.of(context).textTheme.bodyLarge,), centerTitle: true, backgroundColor: AppColors.secondary, foregroundColor: Colors.black,),
        body:  const Center(child: Text("Please take photos")),
      ),
    );
  }
}
