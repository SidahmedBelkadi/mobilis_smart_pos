import '../../domain/entities/sign_in_otp_response_entity.dart';
import '../../domain/entities/password_age_entity.dart';

class SignInOTPResponseModel extends SignInOTPResponseEntity {
  const SignInOTPResponseModel({
    required super.accessToken,
    required super.refreshToken,
    required super.userIsConsent,
    required super.firstLogin,
    required super.passwordAge,
    super.userId,
    super.employeeId,
    super.msisdn,
    super.pdvCode,
  });

  factory SignInOTPResponseModel.fromJson(Map<String, dynamic> json) {
    return SignInOTPResponseModel(
      accessToken: json['access_token'] ?? '',
      refreshToken: json['refresh_token'] ?? '',
      userIsConsent: json['user_is_consent'],
      firstLogin: json['first_login'],
      passwordAge: json['password_age'] != null
          ? PasswordAge.fromMap(json['password_age'])
          : null,
      userId: json['user_id'],
      employeeId: json['employee_id'],
      msisdn: json['msisdn'],
      pdvCode: json['pdv_code'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'access_token': accessToken,
      'refresh_token': refreshToken,
      'user_is_consent': userIsConsent,
      'first_login': firstLogin,
      'password_age': passwordAge?.toMap(),
      'user_id': userId,
      'employee_id': employeeId,
      'msisdn': msisdn,
      'pdv_code': pdvCode,
    };
  }
}
