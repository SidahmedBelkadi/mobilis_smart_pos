import 'package:equatable/equatable.dart';

class SignInResponseEntity extends Equatable {
  final String message;

  const SignInResponseEntity({
    required this.message,
  });

  @override
  List<Object?> get props => [message];
}
