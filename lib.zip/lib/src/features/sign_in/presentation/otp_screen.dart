import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lottie/lottie.dart';
import 'package:mobilis_smart_pos/src/services/upgrader_service.dart';

import '../../../config/routing/app_routes.dart';
import '../../../core/commom/widgets/otp_custom_widget.dart';
import '../../../core/utils/helpers/app_localization_helper.dart';
import '../../../core/utils/helpers/launch_helper.dart';
import '../../../core/utils/helpers/media_query_values.dart';
import '../../../core/utils/helpers/toast_helper.dart';
import '../../../core/utils/ressources/app_colors.dart';
import '../../../core/utils/ressources/app_images.dart';
import '../../../dependency_injection/injection_container.dart' as di;
import '../domain/entities/sign_in_otp_request_params.dart';
import '../domain/entities/sign_in_request_params.dart';
import 'cubit/sign_in_cubit.dart';

class OTPScreen extends StatelessWidget {
  const OTPScreen({super.key, required this.signInParams});

  final SignInRequestParams signInParams;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<SignInCubit>();

    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Container(
            width: context.width,
            height: context.height,
            padding: EdgeInsets.all(32.sp),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // ------ OTP Animation

                LottieBuilder.asset(
                  AppImages.otp1,
                  height: 170.h,
                  width: 170.w,
                ),
                SizedBox(height: 96.h),

                // ---- OTP Paragraph
                Text(
                  "otp".tr(context),
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall!
                      .copyWith(color: AppColors.primary),
                ),

                SizedBox(height: 64.h),

                // --------- OTP Field & Logic
                BlocConsumer<SignInCubit, SignInState>(
                  listener: (context, state) {
                    if (state is OTPSuccessful) {
                      debugPrint(state.signInOTPResponseEntity.toString());
                      final bool? isFirstLogin = state.signInOTPResponseEntity.firstLogin;

                      final bool? isConsent =    state.signInOTPResponseEntity.userIsConsent;
                      if(isFirstLogin != null && isFirstLogin == true) {
                         Navigator.of(context).pushNamed(Routes.forgotPassword, arguments: {'msisdn': signInParams.phone});
                         return;
                      }
                      if (isConsent != null && isConsent) {
                        Navigator.of(context).pushNamedAndRemoveUntil(
                            Routes.main, (route) => false);
                        return;
                      } else {
                        Navigator.of(context).pushNamedAndRemoveUntil(
                            Routes.pdvEngagements,
                            arguments: {
                              'phone': signInParams.phone,
                              'refresh_token':
                                  state.signInOTPResponseEntity.refreshToken,
                            },
                            (route) => false);
                      }
                    }
                    if (state is OTPFailed) {
                      AppToasts.showErrorToast(
                        message: state.message.tr(context),
                        context: context,
                      );
                    }
                  },
                  builder: (context, state) {
                    if (state is OTPLoading) {
                      return const CircularProgressIndicator();
                    }

                    return OTPCustomWidget(
                      onCompleted: (value) {
                        SignInOTPRequestParams params = SignInOTPRequestParams(
                          msisdn: signInParams.phone,
                          otp: int.parse(value),
                        );
                        cubit.verifyOTP(params: params);
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
