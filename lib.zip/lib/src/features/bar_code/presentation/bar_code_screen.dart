import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lottie/lottie.dart';

import '../../../config/routing/app_routes.dart';
import '../../../core/commom/widgets/app_elevated_button_text.dart';
import '../../../core/utils/helpers/app_localization_helper.dart';
import '../../../core/utils/helpers/media_query_values.dart';
import '../../../core/utils/helpers/toast_helper.dart';
import '../../../core/utils/ressources/app_colors.dart';
import '../../../core/utils/ressources/app_images.dart';
import '../../contract/domain/entities/contract_request_params_entitiy.dart';
import '../../contract/presentation/cubit/contract_cubit.dart';

class SimScannerScreen extends StatefulWidget {
  const SimScannerScreen({
    super.key,
    required this.contract,
    this.recto,
    this.verso,
    required this.isPassport,
    this.parentRecto,
    this.parentVerso,
    this.parentIsPassport,
  });

  final ContractRequestParamsEntitiy contract;
  final File? recto;
  final File? verso;
  final bool isPassport;
  final File? parentRecto;
  final File? parentVerso;
  final bool? parentIsPassport;

  @override
  SimScannerScreenState createState() => SimScannerScreenState();
}

late ContractCubit cubit;
late ContractRequestParamsEntitiy newContract;

class SimScannerScreenState extends State<SimScannerScreen> {
  @override
  void initState() {
    debugPrint("======================== BAR CODE : RECTO : ${widget.recto}");
    debugPrint("======================== BAR CODE : VERSO : ${widget.verso}");
    debugPrint(
        "======================== BAR CODE : ISPASSPORT : ${widget.isPassport}");
    debugPrint(
        "======================== BAR CODE : CONTRACT : ${widget.contract.toJson()}");
    cubit = context.read<ContractCubit>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SingleChildScrollView(
          child: BlocConsumer<ContractCubit, ContractState>(
            listener: (context, state) {
              if (state is CheckBeforeEditContractSuccess) {
                Navigator.of(context).pushNamed(
                  Routes.signatureScreen,
                  arguments: {
                    'contract': newContract,
                    'formattedSmsCode': state.formattedStringWithoutSpaces,
                    'recto': widget.recto,
                    'verso': widget.verso,
                    'isPassport': widget.isPassport,
                    'parentRecto' : widget.parentRecto,
                    'parentVerso' : widget.parentVerso,
                    'parentIsPassport' : widget.parentIsPassport
                  },
                );
              }
              if (state is CheckBeforeEditContractFailed) {
                AppToasts.showErrorToast(
                  message: state.message.tr(context),
                  context: context,
                );
              }
            },
            builder: (context, state) {
              if (state is CheckBeforeEditContractLoading) {
                return SizedBox(
                  height: context.height,
                  child: const Center(child: CircularProgressIndicator()),
                );
              }
              return Container(
                height: context.height,
                width: context.width,
                padding: EdgeInsets.all(32.sp),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Lottie.asset(AppImages.barCodeAnimation5,
                        height: 200.h, width: 200.w),
                    SizedBox(height: 32.h),
                    Text(
                      "bar_code_instruction".tr(context),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                            color: AppColors.primary,
                          ),
                    ),
                    SizedBox(height: 64.h),
                    AppElevatedButtonWithText(
                      text: "start_button".tr(context),
                      onPressed: () {
                        _scanBarCode(context);
                      },
                    )
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      foregroundColor: Colors.black,
      backgroundColor: AppColors.secondary,
      centerTitle: true,
      title: Text(
        "scan_sim".tr(context),
        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
              fontWeight: FontWeight.bold,
            ),
      ),
      actions: [
        PopupMenuButton<String>(
          onSelected: (value) {
            // Handle the selected value here
          },
          itemBuilder: (context) {
            return [
              PopupMenuItem<String>(
                onTap: () {
                  Navigator.of(context)
                      .pushNamedAndRemoveUntil(Routes.main, (route) => false);
                },
                value: 'cancel',
                child: Text("discard_activation".tr(context)),
              ),
            ];
          },
        ),
      ],
    );
  }

  // Future<void> _scanBarCode(BuildContext context) async {
  //   String barCodeScanRes;
  //   try {
  //     barCodeScanRes = await FlutterBarcodeScanner.scanBarcode(
  //       "#91ff59",
  //       "discard".tr(context),
  //       true,
  //       ScanMode.BARCODE,
  //     );
  //     if (barCodeScanRes == "-1") {
  //       return;
  //     }

  //     // Regex to check if the barcode is 13 characters long and starts with "1414"
  //     RegExp regex = RegExp(r'\d{13}$');

  //     if (regex.hasMatch(barCodeScanRes)) {
  //       if (barCodeScanRes.startsWith("892130")) {
  //         barCodeScanRes = barCodeScanRes.substring(6); // Process the barcode
  //       }
  //       _showBarcodeDialog(context, barCodeScanRes); // Show the barcode confirmation dialog
  //     } else {
  //       AppToasts.showErrorToast(message: "invalide_bar_code".tr(context), context: context);
  //     }
  //   } on PlatformException {
  //     return;
  //   }
  // }

  Future<void> _scanBarCode(BuildContext context) async {
    String barCodeScanRes;
    do {
      try {
        barCodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          "#91ff59",
          "discard".tr(context),
          true,
          ScanMode.BARCODE,
        );

        if (barCodeScanRes == "-1") {
          // User pressed cancel
          return;
        }

        // Regex to check if the barcode is 13 characters long
        RegExp regex = RegExp(r'\d{13}$');
        debugPrint("================ $barCodeScanRes");

        if (regex.hasMatch(barCodeScanRes)) {
          if (barCodeScanRes.startsWith("892130")) {
            barCodeScanRes = barCodeScanRes.substring(6);
          }
          debugPrint(
              "================ CAPTURED SUCCESSFULLY : $barCodeScanRes");
          _showBarcodeDialog(context, barCodeScanRes);
          return;
        }
        // If the barcode is not valid, continue scanning
      } on PlatformException {
        return;
      }
    } while (true);
  }

  Future<void> _showBarcodeDialog(BuildContext context, String barcode) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // User must tap a button to dismiss the dialog
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('scanned_bar_code'.tr(context)),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text(
                  barcode,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                SizedBox(height: 16.h),
                Text('scanned_bar_code_question'.tr(context)),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('discard'.tr(context)),
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog
              },
            ),
            ElevatedButton(
              child: Text('yes'.tr(context)),
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog
                _continueWithBarcode(
                    context, barcode); // Continue with the operation
              },
            ),
          ],
        );
      },
    );
  }

  void _continueWithBarcode(BuildContext context, String barcode) {
    setState(() {
      newContract = widget.contract.copyWith(serialNumber: int.parse(barcode));
    });

    debugPrint("======== CONTRACT : $newContract");

    cubit.checkBeforeEditContract(
      contract: newContract,
    );
  }
}
