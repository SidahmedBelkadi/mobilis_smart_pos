import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:mobilis_smart_pos/src/core/commom/widgets/idle.dart';

import '../../../config/routing/app_routes.dart';
import '../../../core/utils/helpers/app_localization_helper.dart';
import '../../../core/utils/helpers/dialog_helper.dart';
import '../../../core/utils/helpers/media_query_values.dart';
import '../../../core/utils/helpers/toast_helper.dart';
import '../../../core/utils/ressources/app_colors.dart';
import '../../../core/utils/ressources/app_images.dart';
import '../../../dependency_injection/injection_container.dart' as di;
import '../../contract/presentation/choose_card_option_screen.dart';
import '../../forgot_password/presentation/cubit/forgot_password_cubit.dart';
import '../../home/presentation/home_screen.dart';
import '../../profile/presentation/cubit/profile_cubit.dart';
import '../../profile/presentation/profile_screen.dart';
import '../../sign_out/presentation/cubit/sign_out_cubit.dart';
import 'widgets/bottom_nav.dart';
import 'widgets/drawer.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key, this.index = 0});

  final int? index;

  @override
  State<MainScreen> createState() => _MyHomePageState();
}

List<Widget> screens = [
  const HomeScreen(),
  const ChooseCardOptionScreen(),
  MultiBlocProvider(
    providers: [
      BlocProvider(
        create: (_) => di.serviceLocator<ForgotPasswordCubit>(),
      ),
      BlocProvider(
        create: (_) => di.serviceLocator<ProfileCubit>()..getPdvInfo(),
      ),
    ],
    child: ProfileScreen(
      authenticationLocalDataSource: di.serviceLocator(),
    ),
  ),
];

List<String> titles = [
  "home",
  "mesActivations",
  "profile",
];
late int screenIndex;

class _MyHomePageState extends State<MainScreen> {
  @override
  void initState() {
    super.initState();
    if (widget.index == null) {
      screenIndex = 0;
    } else {
      screenIndex = widget.index ?? 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Idle(
      child: Scaffold(
        appBar: _buildAppBar(),
        drawer: const HomeDrawer(),
        bottomNavigationBar: CustomAppBottomNavBar(
          currentIndex: screenIndex,
          onTap: (index) => setState(
            () {
              screenIndex = index;
            },
          ),
        ),
        body: screens[screenIndex],
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      centerTitle: true,
      title: Text(
        titles[screenIndex].tr(context),
        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
              color: AppColors.primary,
            ),
      ),
      actions: [
        BlocConsumer<SignOutCubit, SignOutState>(
          listener: (context, state) {
            if (state is SignOutSuccessful) {
              Navigator.of(context).pushNamedAndRemoveUntil(Routes.signIn, (route) => false);
            }
            if (state is SignOutUnSuccessful) {
              AppToasts.showErrorToast(
                  message: "internalServerError".tr(context), context: context);
            }
          },
          builder: (context, state) {
            if (state is SignOutLoading) {
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: 24.sp,
                    width: 24.sp,
                    child: const CircularProgressIndicator(),
                  ),
                  SizedBox(width: 8.sp),
                ],
              );
            }
            return GestureDetector(
              onTap: () => AppDialog.showCustomAppDialog(
                content: "donnection_content".tr(context),
                context: context,
                title: "donnection_title".tr(context),
                onPressed: () {
                  Navigator.of(context).pop();
                  context.read<SignOutCubit>().signOut(context);
                },
              ),
              child: Padding(
                padding: context.isArabicLocale
                    ? EdgeInsets.only(left: 8.sp)
                    : EdgeInsets.only(right: 8.sp),
                child: Image.asset(
                  height: 24.sp,
                  width: 24.sp,
                  AppImages.logout,
                  color: Colors.red,
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
