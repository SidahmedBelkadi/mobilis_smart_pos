import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../../../core/utils/helpers/app_localization_helper.dart';

class LanguageTile extends StatelessWidget {
  final String selectedLanguage;
  final ValueChanged<String> onLanguageChanged;

  const LanguageTile({
    super.key,
    required this.selectedLanguage,
    required this.onLanguageChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const FaIcon(FontAwesomeIcons.language, color: Colors.green),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("Lang".tr(context), style: Theme.of(context).textTheme.bodyLarge),
          DropdownButton<String>(
            dropdownColor: Colors.white,
            value: selectedLanguage,
            icon: const Icon(Icons.arrow_drop_down, color: Colors.green),
            underline: Container(), // Remove the underline
            onChanged: (String? newValue) {
              if (newValue != null) {
                onLanguageChanged(newValue);
              }
            },
            items: <String>['ar', 'en', 'fr'].map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value.tr(context)),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
