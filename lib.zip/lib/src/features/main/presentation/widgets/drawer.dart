import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../config/routing/app_routes.dart';
import '../../../../core/commom/widgets/version.dart';
import '../../../../core/utils/helpers/app_localization_helper.dart';
import '../../../../core/utils/helpers/media_query_values.dart';
import '../../../../core/utils/helpers/toast_helper.dart';
import '../../../../core/utils/ressources/app_images.dart';
import '../../../sign_out/presentation/cubit/sign_out_cubit.dart';
import '../cubits/cubit/locale_cubit.dart';
import 'language_tile.dart';

class HomeDrawer extends StatelessWidget {
  const HomeDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      child: SingleChildScrollView(
        child: SizedBox(
          height: context.height - 64,
          width: context.width,
          child: Column(
            children: [
              Image.asset(
                AppImages.mobilis,
                width: context.width,
                height: 250.sp,
              ),
              const Divider(),
              BlocBuilder<LocaleCubit, ChangeLocalState>(
                builder: (context, state) {
                  return LanguageTile(
                    selectedLanguage: state.locale.languageCode,
                    onLanguageChanged: (value) {
                      context.read<LocaleCubit>().changeLocale(languageCode: value.toString());
                    },
                  );
                },
              ),
              const Divider(),
              const VersionWidget(),
              // ListTile(
              //   onTap: () => Navigator.of(context)
              //       .pushNamed(Routes.chooseCardOption, arguments: {'isContract': true}),
              //   leading: const Icon(Icons.sim_card, color: AppColors.primary),
              //   title: Text("activation".tr(context)),
              // ),
              // const Divider(),
              const Spacer(),
              SizedBox(height: 24.h),
              BlocConsumer<SignOutCubit, SignOutState>(
                listener: (context, state) {
                  if (state is SignOutSuccessful) {
                    Navigator.of(context).pushNamedAndRemoveUntil(Routes.signIn, (route) => false);
                  }
                  if (state is SignOutUnSuccessful) {
                    AppToasts.showErrorToast(
                        message: state.message, onAutoCompleteCompleted: (p0) {}, context: context);
                  }
                },
                builder: (context, state) {
                  if (state is SignOutLoading) {
                    return ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 10.sp),
                        child: SizedBox(
                          height: 24.sp,
                          width: 24.sp,
                          child: const CircularProgressIndicator(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    );
                  }
                  return ElevatedButton(
                    onPressed: () => context.read<SignOutCubit>().signOut(context),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    child: Text("deconnect".tr(context)),
                  );
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
