import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:mobilis_smart_pos/src/core/api/end_points.dart';
import 'package:mobilis_smart_pos/src/services/upgrader_service.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../config/routing/app_routes.dart';
import '../../../core/utils/helpers/app_localization_helper.dart';
import '../../../core/utils/helpers/media_query_values.dart';
import '../../../core/utils/ressources/app_colors.dart';
import '../../../core/utils/ressources/app_images.dart';
import '../../../dependency_injection/injection_container.dart' as di;
import '../../sign_in/data/data_sources/sign_in_local_data_source.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _MyHomePageState();
}


class _MyHomePageState extends State<HomeScreen> {


  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    checkForUpdate();
  }

  Future<void> checkForUpdate() async {
    bool isUpdateAvailable = await di.serviceLocator<UpgraderService>().checkIfLastVersionUpdate();

    if (isUpdateAvailable) {
      _showUpdateDialog();
    } else if (di.serviceLocator<AuthenticationLocalDataSource>().isUpdatePending()) {
      _showUpdateDialog();
    }
  }


  void _showUpdateDialog() {
    showDialog(
      context: context,
      barrierDismissible: false, // This makes the dialog non-dismissible
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Update Available'),
          content: Text('A new version of the app is available. Please update to the latest version.'),
          actions: <Widget>[
            TextButton(
              onPressed: () async {
                final updateUrl = Uri.parse(EndPoints.downloadApk);

                if (await canLaunchUrl(updateUrl)) {
                await launchUrl(updateUrl);
                } else {
                  debugPrint("========= could not launch URL");
                }
              },
              child: const Text('Update Now'),
            ),
          ],
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {



    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          di.serviceLocator<UpgraderService>().checkIfLastVersionUpdate();
        },
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(24.sp),
          height: context.height - 135.sp,
          width: context.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              SizedBox(
                height: 250.sp,
                width: context.width,
                child: HomeBanner(
                  banners: const [
                    AppImages.ban1,
                    AppImages.ban2,
                    AppImages.ban3,
                    AppImages.ban4,
                    AppImages.ban5,
                  ],
                  currentIndex: currentIndex,
                  onPageChanged: (index) {
                    setState(() {
                      currentIndex = index;
                    });
                  },
                ),
              ),
              Column(
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      HomeIcon(
                        image: AppImages.operations,
                        title: "mesOperations".tr(context),
                        onTap: () => Navigator.of(context).pushNamed(Routes.invoices),
                        // isDisabled: true,
                      ),
                      HomeIcon(
                        image: AppImages.ereselli,
                        title: "erselli".tr(context),
                        onTap: () {},
                      ),
                    ],
                  ),
                  SizedBox(height: 24.h),
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      HomeIcon(
                        image: AppImages.activations,
                        title: "mesActivations".tr(context),
                        onTap: () => Navigator.of(context)
                            .pushReplacementNamed(Routes.main, arguments: {'index': 1}),
                      ),
                      HomeIcon(
                        onTap: () => {},
                        image: AppImages.paymentFactures,
                        title: "mesFactures".tr(context),
                        // isDisabled: true,
                      ),
                    ],
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}

class HomeBanner extends StatelessWidget {
  final List<String> banners;
  final int currentIndex;
  final ValueChanged<int> onPageChanged;

  const HomeBanner({
    super.key,
    required this.banners,
    required this.currentIndex,
    required this.onPageChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CarouselSlider(
          items: banners
              .map(
                (imageUrl) => ClipRRect(
                  borderRadius: BorderRadius.circular(16.0),
                  child: Image(
                    image: AssetImage(imageUrl),
                    fit: BoxFit.cover,
                  ),
                ),
              )
              .toList(),
          options: CarouselOptions(
            viewportFraction: 1,
            autoPlay: true,
            autoPlayInterval: const Duration(seconds: 3),
            autoPlayAnimationDuration: const Duration(milliseconds: 500),
            pauseAutoPlayOnTouch: true,
            enlargeCenterPage: true,
            onPageChanged: (index, reason) => onPageChanged(index),
          ),
        ),
        SizedBox(height: 24.0.h), // Adjust the height as needed
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            banners.length,
            (index) => AnimatedContainer(
              duration: const Duration(seconds: 1),
              height: 6.h,
              width: currentIndex == index ? 30.w : 6.w,
              margin: const EdgeInsets.symmetric(horizontal: 4.0),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(100),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class HomeIcon extends StatelessWidget {
  const HomeIcon({
    super.key,
    required this.image,
    required this.title,
    this.onTap,
    this.isDisabled = false,
  });

  final String image;
  final String title;
  final void Function()? onTap;
  final bool isDisabled;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          // Container(
          //   height: 80.h,
          //   width: 80.w,
          //   padding: EdgeInsets.all(8.sp),
          //   decoration: BoxDecoration(
          //     color: isDisabled ? Colors.grey : AppColors.secondaryLight,
          //     borderRadius: BorderRadius.all(
          //       Radius.circular(12.sp),
          //     ),
          //     border: Border.all(color: isDisabled ? Colors.grey : AppColors.grey),
          //   ),
          //   child: Image.asset(image, height: 80.h, width: 80.w),
          // ),

          Image.asset(image, height: 110.sp, width: 110.sp),
          // SizedBox(height: 8.sp),
          Text(
            title,
            style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                  color: isDisabled ? Colors.grey : Colors.black.withOpacity(.8),
                  fontSize: 12.sp,
                ),
          ),
        ],
      ),
    );
  }
}

class HomeFAB extends StatelessWidget {
  const HomeFAB({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: () =>
          Navigator.of(context).pushNamed(Routes.chooseCardOption, arguments: {'isContract': true}),
      label: const Text("Vendre"),
      icon: const Icon(Icons.add),
    );
  }
}
