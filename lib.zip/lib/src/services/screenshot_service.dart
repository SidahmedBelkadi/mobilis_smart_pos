import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';

class ScreenshotService {
  static const platform = MethodChannel('channel');

  static Future<void> disableScreenshots() async {
    try {
      await platform.invokeMethod('disableScreenshots');
      debugPrint("========= Disabled SCREENSHOTS");
    } on PlatformException catch (e) {
      debugPrint("$e");
    }
  }

  static Future<void> enableScreenshots() async {
    try {
      await platform.invokeMethod('enableScreenshots');
      debugPrint("========= ENABLED SCREENSHOTS");
    } on PlatformException catch (e) {
      debugPrint("$e");
    }
  }
}