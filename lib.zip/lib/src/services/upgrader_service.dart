import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:mobilis_smart_pos/src/core/api/dio_consumer.dart';
import 'package:mobilis_smart_pos/src/core/api/end_points.dart';
import 'package:mobilis_smart_pos/src/features/sign_in/data/data_sources/sign_in_local_data_source.dart';
import 'package:mobilis_smart_pos/src/services/notification_service.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../dependency_injection/injection_container.dart' as di;

class UpgraderService {

  final DioConsumer dio;

  const UpgraderService({required this.dio});

  Future<bool> checkIfLastVersionUpdate() async {
    try {
      final storage = di.serviceLocator<AuthenticationLocalDataSource>();

      // Get the last checked update date
      final DateTime? lastCheckDate = storage.getCheckedUpdatedDate();

      // Check if 30 minute has passed since the last check
      if (lastCheckDate != null && DateTime.now().difference(lastCheckDate).inMinutes < 30) {
        debugPrint('============================ Last check was less than 30 minute ago, skipping update check');
        return false;
      }

      // Get the current app version
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      String currentVersion = packageInfo.version;

      // Fetch the latest version from the server
      final response = await dio.get(EndPoints.appVersion);
      final serverVersion = jsonDecode(response)['version'];

      // Compare the versions
      if (_isUpdateAvailable(currentVersion, serverVersion)) {
        debugPrint('============== Update available: Server version $serverVersion, Current version $currentVersion');

        // Save the current time as the last checked update date
        storage.saveCheckedUpdateDate(DateTime.now());

        // Mark the update as pending
        storage.setUpdatePending(true);

        return true;
      } else {
        debugPrint('============================ App is up to date: Current version $currentVersion');
        storage.setUpdatePending(false);
        return false;
      }
    } catch (e) {
      debugPrint('Error checking app version: $e');
      return false; // Return false if an error occurs
    }
  }


  bool _isUpdateAvailable(String currentVersion, String serverVersion) {
    // Split versions into parts and compare each part
    List<String> currentParts = currentVersion.split('.');
    List<String> serverParts = serverVersion.split('.');

    for (int i = 0; i < currentParts.length; i++) {
      int currentPart = int.parse(currentParts[i]);
      int serverPart = int.parse(serverParts[i]);

      if (serverPart > currentPart) {
        return true;
      } else if (serverPart < currentPart) {
        return false;
      }
    }
    return false;
  }

}
