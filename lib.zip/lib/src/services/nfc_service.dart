import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NFCService {
  static const platform = MethodChannel('channel');

  Future<Map<String, dynamic>> readNfc(
      String documentType,
      String documentNumber,
      String dateOfBirth,
      String dateOfExpiry,
      bool exractFacialImage,
      bool extrcatSignature) async {
    try {
      final String result = await platform.invokeMethod('readNfc', {
        'documentType': documentType,
        'documentNumber': documentNumber,
        'dateOfBirth': dateOfBirth,
        'dateOfExpiry': dateOfExpiry,
        'exractFacialImage': exractFacialImage,
        'extrcatSignature': extrcatSignature,
      });
      debugPrint("=========== NFC scan started: $result");
      return Map<String, dynamic>.from(json.decode(result));
    } on PlatformException catch (e) {
      debugPrint("=================== Error starting NFC scan: ${e.message}");
      return {'error': 'Failed to start NFC scan: ${e.message}'};
    }
  }
}
