import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/helpers/app_localization_helper.dart';
import '../../utils/ressources/app_colors.dart';

class VersionWidget extends StatelessWidget {
  const VersionWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: AppColors.secondaryLight,
          borderRadius: BorderRadius.all(
            Radius.circular(8.sp),
          ),
          border: Border.all(color: AppColors.secondary)),
      padding: EdgeInsets.symmetric(horizontal: 4.sp, vertical: 4.sp),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "version".tr(context),
            style: Theme.of(context).textTheme.labelSmall!.copyWith(color: AppColors.primary),
          ),
          Text(
            "1.0.1",
            style: Theme.of(context)
                .textTheme
                .labelSmall!
                .copyWith(color: AppColors.primary, fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }
}
