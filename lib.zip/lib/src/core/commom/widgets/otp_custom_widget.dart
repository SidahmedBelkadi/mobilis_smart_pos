
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pinput/pinput.dart';

import '../../utils/ressources/app_colors.dart';

class OTPCustomWidget extends StatelessWidget {
  const OTPCustomWidget({
    super.key,
    this.onCompleted,
  });

  final void Function(String)? onCompleted;

  @override
  Widget build(BuildContext context) {
    const focusedBorderColor = AppColors.primary;
    const fillColor = Color.fromRGBO(243, 246, 249, 0);
    const borderColor = AppColors.secondary;

    final defaultPinTheme = PinTheme(
      width: 60.sp,
      height: 60.sp,
      textStyle: TextStyle(
        fontSize: 16.sp,
        color: const Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(19.sp),
        border: Border.all(color: borderColor),
      ),
    );

    return Directionality(
      textDirection: TextDirection.ltr,
      child: Pinput(
        length: 6,
        obscureText: false,
        autofocus: false,
        validator: (value) {
          // Check if the input is exactly 6 digits long and numeric
          if (value == null || value.isEmpty) {
            return 'This field is required';
          } else if (value.length != 6) {
            return 'Enter exactly 6 digits';
          } else if (!RegExp(r'^\d+$').hasMatch(value)) {
            return 'Only numeric digits are allowed';
          }
          return null;
        },
        hapticFeedbackType: HapticFeedbackType.heavyImpact,
        focusedPinTheme: defaultPinTheme.copyWith(
          decoration: defaultPinTheme.decoration!.copyWith(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: focusedBorderColor, width: 2),
          ),
        ),
        submittedPinTheme: defaultPinTheme.copyWith(
          decoration: defaultPinTheme.decoration!.copyWith(
            color: fillColor,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: focusedBorderColor, width: 2),
          ),
        ),
        errorPinTheme: defaultPinTheme.copyBorderWith(
          border: Border.all(color: Colors.redAccent),
        ),
        onCompleted: onCompleted,
      ),
    );
  }
}
