import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:idle_detector_wrapper/idle_detector_wrapper.dart';
import '../../../features/sign_out/presentation/cubit/sign_out_cubit.dart';

class Idle extends StatelessWidget {
  const Idle({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return IdleDetector(
      idleTime: const Duration(hours: 5),
      onIdle: () {
        context.read<SignOutCubit>().signOut(context);
      },
      child: child,
    );
  }
}
