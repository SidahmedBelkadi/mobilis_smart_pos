class StatusCode {
  StatusCode._();

  static const int ok = 200;
  static const int badRequest = 400;
  static const int unauthorized = 401;
  static const int forbidden = 403;
  static const int notFound = 404;
  static const int conflict = 409;
  static const int unprocessable = 422;
  static const int internalServerError = 500;
  static const int tokenExpired = 498;
}
