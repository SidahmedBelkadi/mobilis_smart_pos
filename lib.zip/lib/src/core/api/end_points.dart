class EndPoints {
  EndPoints._();

  // ============== BASE URLS ===================

  static const String ocrBaseUrl = String.fromEnvironment("OCR_BASE_URL");
  // static const String baseUrl = "https://ms-pos.mobilis.dz/api";
    static const String baseUrl = "http://192.168.1.10:3002/api";

  // ============== APK ================== //
  static const String downloadApk = "https://ms-pos.mobilis.dz/apk";

  // ============== AUTH =================== //
  static const String signUp = "$baseUrl/sign";
  static const String signIn = "$baseUrl/login";
  static const String refreshToken = "$baseUrl/refresh";
  static const String verifyOTP = "$baseUrl/login/verify-otp";
  static const String approveContract = "$baseUrl/login/approval";
  static const String resetPasswordOTP = "$baseUrl/user/password/request-otp";
  static const String resetPassword = "$baseUrl/user/password/update";
  static const String signOut = "$baseUrl/logout";

  // ================= PDV =============== //
  static const String profile = "$baseUrl/pdv";
  static const String invoices = "$baseUrl/pdv/invoices/all";
  static const String updatePDV = "$baseUrl/employee";
  static const String uploadPDV = "$baseUrl/file/employee";

  // ================== CLIENT ================= //
  static const String checkBeforeEditContract = "$baseUrl/contract/check-before-edit";
  static const String editContract = "$baseUrl/contract/edit";
  static const String generateContrcat = "$baseUrl/contract/attributeMSISDN";
  static const String uploadClient = "$baseUrl/file/client";

  // ================== OCR =================== //
  static const String processId = "$ocrBaseUrl/process_id";
  static const String processPassport = "$ocrBaseUrl/process_passport";

// ================== app Version check =================== //
static const String appVersion = "$baseUrl/mobile_version/last";

}
