import 'package:flutter/material.dart';
import 'package:toastification/toastification.dart';

abstract class AppToasts {
  static void showSuccessToast({required String message, required BuildContext context}) {
    toastification.show(
      context: context,
      title: Text(
        message,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      autoCloseDuration: const Duration(seconds: 5),
      showProgressBar: false,
      type: ToastificationType.success,
      style: ToastificationStyle.flat,
    );
  }

  static void showInfoToast({required String message, required BuildContext context}) {
    toastification.show(
      context: context,
      title: Text(
        message,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      autoCloseDuration: const Duration(seconds: 5),
      showProgressBar: false,
      type: ToastificationType.info,
      style: ToastificationStyle.flat,
    );
  }

  static void showErrorToast(
      {required String message,
      Function(ToastificationItem)? onAutoCompleteCompleted,
      required BuildContext context}) {
    toastification.show(
        context: context,
        title: Text(
          message,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        autoCloseDuration: const Duration(seconds: 6),
        showProgressBar: false,
        closeButtonShowType: CloseButtonShowType.none,
        type: ToastificationType.error,
        style: ToastificationStyle.flat,
        callbacks: ToastificationCallbacks(
          onAutoCompleteCompleted: onAutoCompleteCompleted,
        ));
  }

  static void showWarningToast({required String message, required BuildContext context}) {
    toastification.show(
      context: context,
      title: Text(
        message,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      autoCloseDuration: const Duration(seconds: 5),
      showProgressBar: false,
      type: ToastificationType.warning,
      style: ToastificationStyle.flat,
    );
  }
}
