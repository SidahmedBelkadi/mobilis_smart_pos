import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'media_query_values.dart';

class CivilsInformationsConverterHelper {
  CivilsInformationsConverterHelper._();

  static String activationSerialNumberPrefix = "892130";

  static String getFormatedGender({required String gender, required BuildContext context}) {
    if (gender == "MALE") {
      if (context.isArabicLocale) {
        return "ذكر";
      } else if (context.isFrenchLocale) {
        return "Homme";
      } else {
        return "Male";
      }
    } else {
      if (context.isArabicLocale) {
        return "أنثى";
      } else if (context.isFrenchLocale) {
        return "Femme";
      } else {
        return "Female";
      }
    }
  }

  static String getToSubmitGenderValue({required String gender}) {
    if (gender == "MALE") {
      return "Male";
    } else {
      return "Female";
    }
  }

  static String getToSubmitDocumentTypeValue({required String docType}) {
    if (docType == "passport") {
      return "Passport";
    }
    return "ID Card";
  }

  static String getDocumentTypeName({required String docType, required BuildContext context}) {
    if (context.isArabicLocale) {
      if (docType == "passport") {
        return "جواز سفر";
      }
      return "بطاقة التعريف الوطنية";
    } else if (context.isFrenchLocale) {
      if (docType == "passport") {
        return "Passeport";
      }
      return "Carte d'identité";
    } else {
      if (docType == "passport") {
        return "Passport";
      }
      return "Identity Card";
    }
  }

  static String formatToDisplayDate({required String date, required BuildContext context}) {
    DateTime parsedDate = DateFormat('yyyy-mm-dd').parse(date);
    if (context.isArabicLocale) {
      return date;
    } else if (context.isFrenchLocale) {
      return DateFormat('dd-mm-yyyy').format(parsedDate);
    } else {
      return date;
    }
  }

  static String convertDateFormat({required String date}) {
    DateTime parsedDate = DateFormat('yyyy/MM/dd').parse(date);
    String formattedDate = DateFormat('dd-MM-yyyy').format(parsedDate);
    return formattedDate;
  }

  static String convertToIso8601(String dateStr) {
    final inputFormat = DateFormat('dd/MM/yyyy');

    final dateTime = inputFormat.parse(dateStr);

    final iso8601Str = dateTime.toIso8601String();

    return iso8601Str;
  }

  static String convertToIso8601WithTiret(String dateStr) {
    final inputFormat = DateFormat('yyyy-mm-dd');

    final dateTime = inputFormat.parse(dateStr);

    final iso8601Str = dateTime.toIso8601String();

    return iso8601Str;
  }
}
