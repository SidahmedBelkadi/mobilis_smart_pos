import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SecurityCheck {
  static const platform = MethodChannel('channel');

  Future<bool> checkSecurity() async {
    try {
      final bool result = await platform.invokeMethod('security_check');
      return result;
    } on PlatformException catch (e) {
      debugPrint("=================== Failed to check security: '${e.message}'.");
      return false;
    }
  }
}
