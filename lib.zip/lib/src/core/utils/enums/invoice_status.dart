import 'package:flutter/material.dart';

import '../ressources/app_colors.dart';

class InvoiceStatusEnum {
  final String name;
  final Color color;
  final Color backgroundColor;

  const InvoiceStatusEnum._(this.name, this.color, this.backgroundColor);

  static const InvoiceStatusEnum paid = InvoiceStatusEnum._(
    "Payé",
    AppColors.inProgressTextColor,
    AppColors.secondaryLight,
  );

  static const InvoiceStatusEnum notPaid = InvoiceStatusEnum._(
    "Non Payé",
    AppColors.waitingTextColor,
    AppColors.waittingBackgroundColor,
  );

  static const List<InvoiceStatusEnum> values = [paid, notPaid];
}
