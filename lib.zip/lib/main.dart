import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:mobilis_smart_pos/src/services/notification_service.dart';
import 'package:pretty_bloc_observer/pretty_bloc_observer.dart';


import 'src/app.dart';
import 'src/dependency_injection/injection_container.dart' as di;



void main() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();

  debugPrint("====== Main: App initialization started ======");

  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);

  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await Future.delayed(const Duration(milliseconds: 150));

  // Initialize Service Locator for Dependency Injection
  await di.initializeAppDependencies();
  await NotificationService.init();

  // Register Bloc Observer
  Bloc.observer = PrettyBlocObserver();
  FlutterNativeSplash.remove();

  runApp(const SmartPos());
}
